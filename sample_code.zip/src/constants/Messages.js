export const ErrorMessages = {
  EMAIL_INVALID: "Email is invalid.",
  EMAIL_REQUIRED: "Email is required.",
  PASSWORD_REQUIRED: "Password is required.",
  PASSWORD_MATCH: "Password did not match.",
};

