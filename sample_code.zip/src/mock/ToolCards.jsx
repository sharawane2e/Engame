 import Archetypes from "../assets/images/Archetypes.svg";
 import Artcards from "../assets/images/Artcards.svg";
 import BrandTarget from "../assets/images/BrandTarget-dnd.svg";
 import Container_exclusive_dnd from "../assets/images/Container_exclusive_dnd.svg";
 import E_clinic from "../assets/images/E-clinic.svg";


const toolsCrad = [
    {
        imgUrl: Container_exclusive_dnd,
         name:"Target Drag & Drop",
         showDownload:true,
         showAddToCart:true,
         price:21,
         currency:"$",
         toolname:"Target Drag & Drop"
         
     },
    {
        imgUrl:BrandTarget,
         name:"Brand Sorting",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Brand Sorting"
         
     },
    {
        imgUrl:E_clinic,
         name:"E-Clinic",
         showDownload:true,
         showAddToCart:true,
         price:21,
         currency:"$",
         toolname:"E-Clinic"
     },
    {
        imgUrl:E_clinic,
         name:"Implicit Exercise",
         showDownload:true,
         showAddToCart:true,
         price:45,
         currency:"$",
         toolname:"Implicit Exercise"
     },
    {
        imgUrl:Artcards,
         name:"Artcards",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Artcards"
     },
    {
        imgUrl:Artcards,
         name:"Artcards",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Artcards"
     },
    {
        imgUrl:Artcards,
         name:"Artcards",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Artcards"
     },
    {
        imgUrl:Artcards,
         name:"Artcards",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Artcards"
     },
    {
        imgUrl:Artcards,
         name:"Artcards",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Artcards"
     },
    {
        imgUrl:Artcards,
         name:"Artcards",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Artcards"
     },
    {
        imgUrl:Artcards,
         name:"Artcards",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Artcards"
     },
    {
        imgUrl:Artcards,
         name:"Artcards",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Artcards"
     },
    {
        imgUrl:Artcards,
         name:"Artcards",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Artcards"
     },
    {
        imgUrl:Artcards,
         name:"Artcards",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Artcards"
     },
    {
        imgUrl:Artcards,
         name:"Artcards",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Artcards"
     },
    {
        imgUrl:Artcards,
         name:"Artcards",
         showDownload:true,
         showAddToCart:true,
         price:32,
         currency:"$",
         toolname:"Artcards"
     },


 ]
 export default toolsCrad;