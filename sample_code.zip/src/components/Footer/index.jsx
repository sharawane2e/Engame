import React from 'react';

function Footer(props) {
    return (
        <>
       <div className="footer">This is footer</div>
        </>
    );
}

export default Footer;