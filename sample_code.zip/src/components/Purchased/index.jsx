import React from 'react';

function Purchased(props) {
    return (
        <div>
            This is purchased tool
        </div>
    );
}

export default Purchased;