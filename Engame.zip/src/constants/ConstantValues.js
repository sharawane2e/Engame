export const LOGOUT_TIME = 10800000; // Time is in minlisecond
export const EMAIL_LENGTH = 100;
export const PASSWORD_MAX_LENGTH = 16;
export const PASSWORD_MIN_LENGTH = 8;
export const FIRSTNAME_LENGTH = 50;
export const LASTNAME_LENGTH = 50;
