import * as actionTypes from "./user-types";
import ApiRequest from "../../util/ApiRequest";
import LocalStorageUtils from "../../util/LocalStorageUtils";
import LocalStorageType from "../../config/LocalStorageType";
const initialState = {
  isLoggedIn: false,
};

const getAuthState = () => {
  const auth = localStorage.getItem("auth");
  try {
    const authObj = JSON.parse(auth);
    const { access_token, refresh_token } = authObj.token;
    return authObj;
  } catch (error) {
    return initialState;
  }
};

const newAuth = getAuthState();

const userReducer = (state = newAuth, action) => {
  switch (action.type) {
    case actionTypes.LOGIN_SUCCESS:
      const newState = {
        isLoggedIn: true,
        token: action.payload,
      };
      LocalStorageUtils.setLocalStorage(
        LocalStorageType.SET,
        "auth",
        JSON.stringify(newState)
      );

      return newState;

    case actionTypes.LOGOUT:
      LocalStorageUtils.setLocalStorage(LocalStorageType.CLEAR);
      return initialState;
    default:
      return state;
  }
};

export default userReducer;
