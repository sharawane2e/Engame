// import { PAYMENT_SUCESS, PAYMENT_NOTSET } from "./payment-message";
// import axios from "axios";
// import { BASE_URL } from "../../config/ApiUrl";

// export const PaymentData = () => (dispatch) => {
//   dispatch({
//     type: PAYMENT_SUCESS,
//   });
//   //   try {
//   // const { data } = await axios.get(BASE_URL + "widget/");
//   dispatch({ type: PRODUCT_LIST_SUCCESS, payload: data });
//   //   } catch (error) {
//   dispatch({ type: PRODUCT_LIST_FAIL, payload: error.message });
//   //   }
// };
