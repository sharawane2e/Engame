// import { PAYMENT_SUCESS, PAYMENT_NOTSET } from "./payment-message";

// export const productListReducer = (state = { products: [] }, action) => {
//   switch (action.type) {
//     case PAYMENT_SUCESS:
//       return { products: action.payload };

//     case PAYMENT_NOTSET:
//       return { error: action.payload };

//     default:
//       return state;
//   }
// };
