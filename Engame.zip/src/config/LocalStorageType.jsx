const LocalStorageType = {
  SET: "set",
  REMOVE: "remove",
  CLEAR: "clear",
  GET: "get",
};

export default LocalStorageType;
