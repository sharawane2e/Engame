import AppRouting from "../../AppRouting";

const PublicScreen = (props) =>{
    return(
        <AppRouting routes={props.routes} />
    )
}

export default PublicScreen;