const Embedcode = [
    {
    id:10,
    embed:`
        '<script  src="https://e2eresearch.com/swteam/html5Tools/testTool/craousal_Rating/js/jquery-2.2.4.min.js"></script>
        <script  src="https://e2eresearch.com/swteam/html5Tools/testTool/craousal_Rating/js/script.min.js"></script>
        <link rel="stylesheet" href="https://e2eresearch.com/swteam/html5Tools/testTool/craousal_Rating/css/style.min.css" />

        <script>
            strImgValues = "Statement 1||Statement 2||Statement 3||Statement 4||Statement 5||Statement 6||Statement 7||Statement 8||Statement 9||Statement 10";
            strScaleValues = "Poor||Fair||Good||Very Good||Excellent";
            function output(data){
                $(".output").val(data);
            }
        </script>

        <div class="carousel-rating-container" id="toolwrapper"></div>
        <input type="text" id="outputValue" class="output"/>'
    `},
    {
    id:12,
    embed:`
        '<script  src="https://e2eresearch.com/swteam/html5Tools/testTool/craousal_Rating/js/jquery-2.2.4.min.js"></script>
        <script  src="https://e2eresearch.com/swteam/html5Tools/testTool/craousal_Rating/js/script.min.js"></script>
        <link rel="stylesheet" href="https://e2eresearch.com/swteam/html5Tools/testTool/craousal_Rating/css/style.min.css" />

        <script>
            strImgValues = "Statement 1||Statement 2||Statement 3||Statement 4||Statement 5||Statement 6||Statement 7||Statement 8||Statement 9||Statement 10";
            strScaleValues = "Poor||Fair||Good||Very Good||Excellent";
            function output(data){
                $(".output").val(data);
            }
        </script>

        <div class="carousel-rating-container" id="toolwrapper"></div>
        <input type="text" id="outputValue" class="output"/>'
    `},
    {
    id:13,
    embed:`
        '<script  src="https://e2eresearch.com/swteam/html5Tools/testTool/craousal_Rating/js/jquery-2.2.4.min.js"></script>
        <script  src="https://e2eresearch.com/swteam/html5Tools/testTool/craousal_Rating/js/script.min.js"></script>
        <link rel="stylesheet" href="https://e2eresearch.com/swteam/html5Tools/testTool/craousal_Rating/css/style.min.css" />

        <script>
            strImgValues = "Statement 1||Statement 2||Statement 3||Statement 4||Statement 5||Statement 6||Statement 7||Statement 8||Statement 9||Statement 10";
            strScaleValues = "Poor||Fair||Good||Very Good||Excellent";
            function output(data){
                $(".output").val(data);
            }
        </script>

        <div class="carousel-rating-container" id="toolwrapper"></div>
        <input type="text" id="outputValue" class="output"/>'
    `},
]
export default Embedcode;