const tools = [
    {
        imgUrl:"./assets/E2E-logo.png",
        name:"Target2",
    },
    {
        imgUrl:"./assets/E2E-logo.png",
        name:"Target1",
    },
    {
        imgUrl:"./assets/E2E-logo.png",
        name:"Target1",
    },
    {
        imgUrl:"./assets/E2E-logo.png",
        name:"Target2",
    },
    // {
    //     imgUrl:"",
    //     name:"Target",
    //     showDownload:true,
    //     showAddToCart:true,
    //     price:21,
    //     currency:"$",
    //     toolname:""
        
    // }
]