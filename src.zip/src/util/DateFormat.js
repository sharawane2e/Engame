const dateFormat = () =>{
    return "29-11-2020";
}
export default dateFormat